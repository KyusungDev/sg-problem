export const MAX_PAGE_LEN = 4;
export const MSG_REQUIRED = '값을 입력해주세요!';
